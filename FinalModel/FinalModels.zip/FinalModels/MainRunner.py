from FinalModels.Main import Main

main = Main()
#main.CreateModel(0)
main.PredictValues(0,[50,50,50,50,50,50,50,50,50,50,50,50,50])
print()